# Glassy Launcher 2.0 – tvOS-style launcher with live weather widget

## Build the APK without a PC setup (GitHub)
1. Create a free GitHub repo and upload this whole folder (keep `.github/workflows/build.yml`).
2. Open the **Actions** tab -> *Build APK* -> **Run workflow** (it also runs on every push).
3. When finished, download the **GlassyLauncher-apk** artifact (zip) -> `app-debug.apk`.
4. Install on the TV (adb or "Send files to TV"). Uninstall the old Glassy Launcher first (different signature).

## Build in Android Studio
Open the folder -> let Gradle sync -> *Build > Build APK(s)*. (JDK 17, SDK 34.)

## Using it
- Weather card is top-right. Focus it with D-pad UP from the app row.
  OK = refresh now, MENU = change city.
- MENU button anywhere (or the first "Settings" tile) opens the settings drawer:
  wallpaper (LEFT/RIGHT to change), choose picture, widget on/off, location mode,
  change city, refresh, set as default home.
- Extra wallpapers: copy images to `Android/data/com.example.glassylauncher/files/wallpapers/`
  and they appear in the wallpaper list automatically.
- Weather: Open-Meteo (no API key). Auto location uses device location if permitted,
  otherwise approximate IP location. Refreshes every 30 min, cached for offline use.

## Code map (app/src/main/java/com/example/glassylauncher)
MainActivity (home screen, apps, wiring) | WeatherWidgetView (glass card + animations)
WeatherRepository (location, Open-Meteo, cache) | WeatherData / WeatherCodes
WallpaperView / WallpaperStore (changeable wallpaper + blur) | SettingsPanel (drawer)
