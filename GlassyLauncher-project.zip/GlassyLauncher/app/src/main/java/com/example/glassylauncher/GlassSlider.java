package com.example.glassylauncher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.Rect;
import android.view.KeyEvent;
import android.view.View;

/** Pill-shaped slider (LEFT/RIGHT on the remote changes the value). */
final class GlassSlider extends View {
    interface OnChange { void onChange(int v); }

    private final String label;
    private final float u;
    private final OnChange cb;
    private int value, accent;
    private boolean focused;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path clip = new Path();

    GlassSlider(Context c, String label, float u, int initial, int accent, OnChange cb) {
        super(c);
        this.label = label; this.u = u; this.value = initial; this.accent = accent; this.cb = cb;
        setFocusable(true);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        p.setStyle(Paint.Style.FILL);
    }

    void setAccent(int a) { accent = a; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), rad = h / 2f;
        r.set(0, 0, w, h);
        p.setColor(focused ? 0x4DFFFFFF : 0x30FFFFFF);
        c.drawRoundRect(r, rad, rad, p);
        c.save();
        clip.reset();
        clip.addRoundRect(r, rad, rad, Path.Direction.CW);
        c.clipPath(clip);
        p.setColor((accent & 0x00FFFFFF) | 0xD0000000);
        c.drawRect(0, 0, w * value / 100f, h, p);
        c.restore();
        t.setColor(0xFFFFFFFF);
        t.setTextSize(1.45f * u);
        t.setShadowLayer(u * 0.2f, 0, u * 0.08f, 0x66000000);
        float y = h / 2f + 0.5f * u;
        t.setTextAlign(Paint.Align.LEFT);
        c.drawText(label, 1.6f * u, y, t);
        t.setTextAlign(Paint.Align.RIGHT);
        c.drawText(String.valueOf(value), w - 1.6f * u, y, t);
        if (focused) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.18f * u);
            p.setColor(0xF2FFFFFF);
            r.set(0.09f * u, 0.09f * u, w - 0.09f * u, h - 0.09f * u);
            c.drawRoundRect(r, rad, rad, p);
            p.setStyle(Paint.Style.FILL);
        }
    }

    @Override protected void onFocusChanged(boolean gained, int dir, Rect prev) {
        super.onFocusChanged(gained, dir, prev);
        focused = gained;
        invalidate();
    }

    @Override public boolean onKeyDown(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT) {
            int nv = Math.max(0, Math.min(100, value + (code == KeyEvent.KEYCODE_DPAD_LEFT ? -5 : 5)));
            if (nv != value) { value = nv; cb.onChange(nv); invalidate(); }
            return true;
        }
        return super.onKeyDown(code, e);
    }
}
