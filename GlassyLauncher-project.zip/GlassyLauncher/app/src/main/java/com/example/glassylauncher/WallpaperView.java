package com.example.glassylauncher;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.view.View;

/** Full-screen wallpaper with cross-fade. Also keeps a blurred copy for the glass widget. */
public class WallpaperView extends View {
    private Bitmap cur, prev, blur;
    private float fade = 1f;
    private ValueAnimator anim;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint scrim = new Paint();
    private final Rect src = new Rect(), dst = new Rect();

    public WallpaperView(Context c) {
        super(c);
        setFocusable(false);
    }

    public Bitmap getBlur() { return blur; }

    public void setWallpaper(Bitmap b, boolean animate) {
        if (b == null) return;
        if (anim != null) anim.cancel();
        prev = animate ? cur : null;
        cur = b;
        buildBlur();
        if (animate && prev != null) {
            fade = 0f;
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(700);
            anim.addUpdateListener(a -> { fade = (Float) a.getAnimatedValue(); invalidate(); });
            anim.addListener(new AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(Animator a) { prev = null; fade = 1f; invalidate(); }
            });
            anim.start();
        } else {
            fade = 1f;
        }
        invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        scrim.setShader(null);
        buildBlur();
    }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (cur == null) { c.drawColor(0xFF05070C); return; }
        if (prev != null) { paint.setAlpha(255); drawCrop(c, prev, w, h); }
        paint.setAlpha((int) (255 * fade));
        drawCrop(c, cur, w, h);
        // readability scrims (top for clock/widget, bottom for app labels)
        scrim.setShader(new LinearGradient(0, 0, 0, h * 0.35f, 0x66000000, 0x00000000, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h * 0.35f, scrim);
        scrim.setShader(new LinearGradient(0, h * 0.55f, 0, h, 0x00000000, 0xB0000000, Shader.TileMode.CLAMP));
        c.drawRect(0, h * 0.55f, w, h, scrim);
    }

    private void drawCrop(Canvas c, Bitmap b, int w, int h) {
        float s = Math.max(w / (float) b.getWidth(), h / (float) b.getHeight());
        int sw = Math.round(w / s), sh = Math.round(h / s);
        int sx = (b.getWidth() - sw) / 2, sy = (b.getHeight() - sh) / 2;
        src.set(Math.max(0, sx), Math.max(0, sy), Math.min(b.getWidth(), sx + sw), Math.min(b.getHeight(), sy + sh));
        dst.set(0, 0, w, h);
        c.drawBitmap(b, src, dst, paint);
    }

    private void buildBlur() {
        if (cur == null || getWidth() == 0 || getHeight() == 0) return;
        int bw = Math.max(16, getWidth() / 12), bh = Math.max(9, getHeight() / 12);
        Bitmap nb = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
        Canvas c = new Canvas(nb);
        float s = Math.max(bw / (float) cur.getWidth(), bh / (float) cur.getHeight());
        int sw = Math.round(bw / s), sh = Math.round(bh / s);
        int sx = (cur.getWidth() - sw) / 2, sy = (cur.getHeight() - sh) / 2;
        Rect sr = new Rect(Math.max(0, sx), Math.max(0, sy), Math.min(cur.getWidth(), sx + sw), Math.min(cur.getHeight(), sy + sh));
        c.drawBitmap(cur, sr, new Rect(0, 0, bw, bh), p);
        boxBlur(nb, 4);
        boxBlur(nb, 4);
        blur = nb;
    }

    private static void boxBlur(Bitmap b, int r) {
        int w = b.getWidth(), h = b.getHeight();
        int[] a = new int[w * h], t = new int[w * h];
        b.getPixels(a, 0, w, 0, 0, w, h);
        pass(a, t, w, h, r, true);
        pass(t, a, w, h, r, false);
        b.setPixels(a, 0, w, 0, 0, w, h);
    }

    private static void pass(int[] in, int[] out, int w, int h, int r, boolean horiz) {
        int lines = horiz ? h : w, len = horiz ? w : h;
        for (int l = 0; l < lines; l++) {
            for (int i = 0; i < len; i++) {
                int rr = 0, g = 0, bl = 0, n = 0;
                for (int k = -r; k <= r; k++) {
                    int j = Math.min(len - 1, Math.max(0, i + k));
                    int c = in[horiz ? l * w + j : j * w + l];
                    rr += (c >> 16) & 255; g += (c >> 8) & 255; bl += c & 255; n++;
                }
                out[horiz ? l * w + i : i * w + l] = 0xFF000000 | ((rr / n) << 16) | ((g / n) << 8) | (bl / n);
            }
        }
    }
}
