package com.example.glassylauncher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final long REFRESH_MS = 30 * 60 * 1000L;   // weather refresh interval
    private static final long RETRY_MS = 2 * 60 * 1000L;       // retry after a failure
    private static final int REQ_LOC = 10, REQ_PICK = 11;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private float u;
    private SharedPreferences prefs;
    private WeatherRepository weather;
    private WallpaperStore wallpapers;

    private FrameLayout root;
    private WallpaperView wallpaper;
    private WeatherWidgetView widget;
    private HorizontalScrollView appsScroll;
    private LinearLayout appsRow;
    private SettingsPanel panel;
    private boolean refreshing;

    private final Runnable refreshTask = this::refreshWeather;

    private static final class AppEntry {
        String label; ComponentName cn; Drawable art; boolean banner;
    }

    // ------------------------------------------------------------------ lifecycle
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        u = dm.widthPixels / 100f;            // resolution-independent unit: 1% of screen width
        prefs = getSharedPreferences("launcher", MODE_PRIVATE);
        weather = new WeatherRepository(this);
        wallpapers = new WallpaperStore(this);

        buildUi();
        setContentView(root);
        hideSystemUi();

        WeatherData cached = weather.loadCached();
        if (cached != null) widget.setData(cached);   // instant offline display
        applyWallpaper(false);
        loadApps();
        requestLocationIfNeeded();
    }

    @Override protected void onResume() {
        super.onResume();
        hideSystemUi();
        WeatherData c = weather.loadCached();
        long age = c == null ? Long.MAX_VALUE : System.currentTimeMillis() - c.updatedMs;
        ui.removeCallbacks(refreshTask);
        if (age >= REFRESH_MS) refreshWeather(); else ui.postDelayed(refreshTask, REFRESH_MS - age);
    }

    @Override protected void onPause() {
        super.onPause();
        ui.removeCallbacks(refreshTask);
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);
    }

    @Override protected void onStop() {
        super.onStop();
        try { unregisterReceiver(pkgReceiver); } catch (Exception ignored) {}
    }

    @Override protected void onNewIntent(Intent i) {      // HOME pressed while we are on top
        super.onNewIntent(i);
        panel.close();
        appsScroll.smoothScrollTo(0, 0);
        if (appsRow.getChildCount() > 2) appsRow.getChildAt(2).requestFocus();
    }

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { loadApps(); }
    };

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    // ------------------------------------------------------------------ UI
    private void buildUi() {
        root = new FrameLayout(this);
        root.setClipChildren(false);

        wallpaper = new WallpaperView(this);
        root.addView(wallpaper, new FrameLayout.LayoutParams(-1, -1));

        // clock + date (top-left)
        LinearLayout clockBox = new LinearLayout(this);
        clockBox.setOrientation(LinearLayout.VERTICAL);
        TextClock clock = new TextClock(this);
        clock.setFormat12Hour("h:mm");
        clock.setFormat24Hour("HH:mm");
        clock.setTextColor(0xFFFFFFFF);
        clock.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        clock.setTextSize(TypedValue.COMPLEX_UNIT_PX, 6.2f * u);
        clock.setShadowLayer(0.4f * u, 0, 0.15f * u, 0x80000000);
        TextClock date = new TextClock(this);
        date.setFormat12Hour("EEEE, d MMMM");
        date.setFormat24Hour("EEEE, d MMMM");
        date.setTextColor(0xCCFFFFFF);
        date.setTextSize(TypedValue.COMPLEX_UNIT_PX, 1.7f * u);
        clockBox.addView(clock);
        clockBox.addView(date);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        clp.setMargins((int) (4 * u), (int) (3 * u), 0, 0);
        root.addView(clockBox, clp);

        // weather widget (top-right)
        widget = new WeatherWidgetView(this);
        widget.setBackdrop(wallpaper);
        widget.setListener(new WeatherWidgetView.Listener() {
            @Override public void onRefreshRequested() { refreshWeather(); }
            @Override public void onCityRequested() { showCityDialog(); }
        });
        FrameLayout.LayoutParams wlp = new FrameLayout.LayoutParams((int) (26 * u), (int) (17 * u), Gravity.TOP | Gravity.END);
        wlp.setMargins(0, (int) (3 * u), (int) (4 * u), 0);
        widget.setVisibility(prefs.getBoolean("widget_on", true) ? View.VISIBLE : View.GONE);
        root.addView(widget, wlp);

        // app row (bottom) – stays fully visible below the widget
        appsRow = new LinearLayout(this);
        appsRow.setOrientation(LinearLayout.HORIZONTAL);
        appsScroll = new HorizontalScrollView(this);
        appsScroll.setHorizontalScrollBarEnabled(false);
        appsScroll.setClipToPadding(false);
        appsScroll.setClipChildren(false);
        appsScroll.setPadding((int) (4 * u), (int) (2 * u), (int) (4 * u), (int) (4 * u));
        appsScroll.addView(appsRow, new ViewGroup.LayoutParams(-2, -2));
        FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        alp.bottomMargin = (int) (3 * u);
        root.addView(appsScroll, alp);

        // settings drawer
        panel = new SettingsPanel(this, host, u);
        root.addView(panel, new FrameLayout.LayoutParams((int) (34 * u), -1, Gravity.END));
    }

    private View makeTile(String labelText, View content, final Runnable click) {
        final int tw = (int) (15 * u), th = (int) (8.4f * u);
        final LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setFocusable(true);
        tile.setClickable(true);

        FrameLayout frame = new FrameLayout(this);
        final GradientDrawable bg = new GradientDrawable();
        final float radius = 1.3f * u;
        final int strokeW = (int) Math.max(1, 0.1f * u);
        bg.setCornerRadius(radius);
        bg.setColor(0x33FFFFFF);
        bg.setStroke(strokeW, 0x40FFFFFF);
        frame.setBackground(bg);
        frame.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius); }
        });
        frame.setClipToOutline(true);
        frame.addView(content);
        tile.addView(frame, new LinearLayout.LayoutParams(tw, th));

        final TextView label = new TextView(this);
        label.setText(labelText);
        label.setTextColor(0xFFFFFFFF);
        label.setTextSize(TypedValue.COMPLEX_UNIT_PX, 1.4f * u);
        label.setGravity(Gravity.CENTER);
        label.setSingleLine(true);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        label.setShadowLayer(0.3f * u, 0, 0.1f * u, 0xCC000000);
        label.setAlpha(0f);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(tw, -2);
        llp.topMargin = (int) (0.9f * u);
        tile.addView(label, llp);

        tile.setOnFocusChangeListener((v, f) -> {
            v.animate().scaleX(f ? 1.12f : 1f).scaleY(f ? 1.12f : 1f).setDuration(160).start();
            label.animate().alpha(f ? 1f : 0f).setDuration(160).start();
            bg.setColor(f ? 0x59FFFFFF : 0x33FFFFFF);
            bg.setStroke(f ? (int) (0.22f * u) : strokeW, f ? 0xE6FFFFFF : 0x40FFFFFF);
            v.setElevation(f ? 2 * u : 0);
        });
        tile.setOnClickListener(v -> click.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(tw, -2);
        lp.rightMargin = (int) (1.8f * u);
        tile.setLayoutParams(lp);
        return tile;
    }

    // ------------------------------------------------------------------ apps
    private void loadApps() {
        io.execute(() -> {
            final List<AppEntry> list = queryApps();
            ui.post(() -> populateApps(list));
        });
    }

    private List<AppEntry> queryApps() {
        PackageManager pm = getPackageManager();
        Set<String> seen = new HashSet<>();
        List<AppEntry> tv = new ArrayList<>(), other = new ArrayList<>();
        collect(pm, Intent.CATEGORY_LEANBACK_LAUNCHER, tv, seen);
        collect(pm, Intent.CATEGORY_LAUNCHER, other, seen);
        Collections.sort(tv, (a, b) -> a.label.compareToIgnoreCase(b.label));
        Collections.sort(other, (a, b) -> a.label.compareToIgnoreCase(b.label));
        tv.addAll(other);
        return tv;
    }

    private void collect(PackageManager pm, String category, List<AppEntry> out, Set<String> seen) {
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(category);
        for (ResolveInfo ri : pm.queryIntentActivities(i, 0)) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            AppEntry e = new AppEntry();
            e.label = String.valueOf(ri.loadLabel(pm));
            e.cn = new ComponentName(pkg, ri.activityInfo.name);
            Drawable d = ri.activityInfo.loadBanner(pm);
            if (d != null) { e.banner = true; e.art = d; } else { e.art = ri.loadIcon(pm); }
            out.add(e);
        }
    }

    private void populateApps(List<AppEntry> list) {
        boolean hadFocus = appsRow.hasFocus();
        appsRow.removeAllViews();

        TextView st = new TextView(this);
        st.setText("Settings");
        st.setTextColor(0xFFFFFFFF);
        st.setTextSize(TypedValue.COMPLEX_UNIT_PX, 2f * u);
        st.setGravity(Gravity.CENTER);
        st.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        appsRow.addView(makeTile("Wallpaper \u00b7 Weather", st, this::openPanel));

        TextView sys = new TextView(this);
        sys.setText("TV Settings");
        sys.setTextColor(0xFFFFFFFF);
        sys.setTextSize(TypedValue.COMPLEX_UNIT_PX, 2f * u);
        sys.setGravity(Gravity.CENTER);
        sys.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        appsRow.addView(makeTile("Wi-Fi \u00b7 Display \u00b7 Sound", sys, () -> host.openSystem(Settings.ACTION_SETTINGS)));

        for (final AppEntry e : list) {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(e.art);
            FrameLayout.LayoutParams lp;
            if (e.banner) {
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                lp = new FrameLayout.LayoutParams(-1, -1);
            } else {
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                lp = new FrameLayout.LayoutParams((int) (5.2f * u), (int) (5.2f * u), Gravity.CENTER);
            }
            iv.setLayoutParams(lp);
            appsRow.addView(makeTile(e.label, iv, () -> launch(e.cn)));
        }
        if ((hadFocus || getCurrentFocus() == null) && appsRow.getChildCount() > 2) {
            appsRow.getChildAt(2).requestFocus();
        } else if (getCurrentFocus() == null) {
            appsRow.getChildAt(0).requestFocus();
        }
    }

    private void launch(ComponentName cn) {
        try {
            startActivity(new Intent(Intent.ACTION_MAIN).setComponent(cn)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED));
        } catch (Exception e) {
            toast("Can't open this app");
        }
    }

    // ------------------------------------------------------------------ weather
    private void refreshWeather() {
        if (refreshing) return;
        refreshing = true;
        ui.removeCallbacks(refreshTask);
        widget.setLoading(true);
        weather.refresh((data, err) -> {
            refreshing = false;
            widget.setLoading(false);
            if (data != null) widget.setData(data);
            widget.setError(err);
            ui.postDelayed(refreshTask, err == null ? REFRESH_MS : RETRY_MS);
        });
    }

    private void requestLocationIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23 && weather.isAuto() && !weather.hasLocationPermission()
                && !prefs.getBoolean("asked_loc", false)) {
            prefs.edit().putBoolean("asked_loc", true).apply();
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOC);
        }
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req != REQ_LOC) return;
        if (!weather.hasLocationPermission()) {
            toast("Location denied \u2013 using approximate location. You can pick a city in Settings.");
        }
        refreshWeather();
    }

    private void showCityDialog() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setHint("City name");
        et.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        final AlertDialog d = new AlertDialog.Builder(this).setTitle("Change city").setView(et)
                .setPositiveButton("Search", null).setNegativeButton("Cancel", null).create();
        d.show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String q = et.getText().toString().trim();
            if (q.length() < 2) return;
            weather.searchCities(q, (places, err) -> {
                if (err != null) { toast(err); return; }
                if (places.isEmpty()) { toast("No cities found"); return; }
                d.dismiss();
                final String[] names = new String[places.size()];
                for (int i = 0; i < names.length; i++) {
                    WeatherRepository.Place p = places.get(i);
                    names[i] = p.subtitle.isEmpty() ? p.name : p.name + " \u2013 " + p.subtitle;
                }
                new AlertDialog.Builder(this).setTitle("Select city").setItems(names, (dlg, which) -> {
                    weather.setManualCity(places.get(which));
                    refreshWeather();
                }).show();
            });
        });
    }

    // ------------------------------------------------------------------ wallpaper
    private void applyWallpaper(final boolean animate) {
        io.execute(() -> {
            Bitmap b = wallpapers.load(wallpapers.current());
            if (b == null) b = wallpapers.load(wallpapers.items().get(0));
            final Bitmap fb = b;
            ui.post(() -> wallpaper.setWallpaper(fb, animate));
        });
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK && res == RESULT_OK && data != null && data.getData() != null) {
            final Uri uri = data.getData();
            io.execute(() -> {
                boolean ok = wallpapers.importFromUri(uri);
                if (ok) wallpapers.select(WallpaperStore.CUSTOM_NAME);
                ui.post(() -> {
                    if (ok) { applyWallpaper(true); panel.refresh(); } else toast("Couldn't load that image");
                });
            });
        }
    }

    // ------------------------------------------------------------------ settings host
    private final SettingsPanel.Host host = new SettingsPanel.Host() {
        @Override public String wallpaperName() { return wallpapers.current().name; }
        @Override public void stepWallpaper(int dir) { wallpapers.step(dir); applyWallpaper(true); }
        @Override public void pickImage() {
            try {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(i, REQ_PICK);
            } catch (Exception e) {
                toast("No file picker on this TV. Copy images to: " + wallpapers.folderPath());
            }
        }
        @Override public boolean widgetEnabled() { return prefs.getBoolean("widget_on", true); }
        @Override public void toggleWidget() {
            boolean on = !widgetEnabled();
            prefs.edit().putBoolean("widget_on", on).apply();
            widget.setVisibility(on ? View.VISIBLE : View.GONE);
        }
        @Override public String locationLabel() { return weather.locationLabel(); }
        @Override public void useAutoLocation() {
            weather.setAuto();
            if (Build.VERSION.SDK_INT >= 23 && !weather.hasLocationPermission()) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOC);
            } else {
                MainActivity.this.refreshWeather();
            }
        }
        @Override public void changeCity() { showCityDialog(); }
        @Override public void refreshWeather() { MainActivity.this.refreshWeather(); }
        @Override public void openHomeSettings() {
            try { startActivity(new Intent(Settings.ACTION_HOME_SETTINGS)); }
            catch (Exception e) {
                try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {}
            }
        }
        @Override public void openSystem(String action) {
            try {
                startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception e) {
                try { startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
                catch (Exception e2) { toast("Can't open TV settings on this device"); }
            }
        }
        @Override public void panelClosed() {
            widget.setFocusable(true);
            appsScroll.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
            if (appsRow.getChildCount() > 0) appsRow.getChildAt(0).requestFocus();
        }
    };

    // ------------------------------------------------------------------ keys
    @Override public boolean onKeyDown(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_MENU || code == KeyEvent.KEYCODE_SETTINGS) {
            if (panel.isOpen()) panel.close(); else openPanel();
            return true;
        }
        return super.onKeyDown(code, e);
    }

    private void openPanel() {
        widget.setFocusable(false);
        appsScroll.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        panel.open();
    }

    @Override public void onBackPressed() {
        if (panel.isOpen()) panel.close();
        // a launcher never exits on Back
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
