package com.example.glassylauncher;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewOutlineProvider;

import java.util.Date;
import java.util.Random;

/**
 * Glass weather card drawn entirely on one Canvas (no child views, no bitmaps per frame).
 * Sized in units of u = width/26 so it looks identical on 1080p and 4K.
 * Frosted look = blurred copy of the wallpaper under the card + dark tint + sky gradient.
 */
public class WeatherWidgetView extends View {

    public interface Listener { void onRefreshRequested(); void onCityRequested(); }

    private static final int N = 40;
    private static final long FRAME_MS = 40; // ~25 fps
    private static final Typeface LIGHT = Typeface.create("sans-serif-light", Typeface.NORMAL);
    private static final Typeface MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private static final Typeface REGULAR = Typeface.create("sans-serif", Typeface.NORMAL);
    private static final String[] LABELS = {"FEELS LIKE", "HUMIDITY", "WIND", "UV INDEX", "SUNRISE", "SUNSET"};

    private WeatherData data;
    private boolean loading;
    private String error;
    private WallpaperView backdrop;
    private Listener listener;

    private float u = 10f, focus = 0f;
    private final long t0 = SystemClock.uptimeMillis();

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cloudPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint text = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path(), tmp = new Path(), tmp2 = new Path();
    private final RectF rf = new RectF();
    private final Rect src = new Rect(), dst = new Rect();
    private Shader sky, gloss, borderShader, sunGlow, moonGlow;

    private final float[] rx = new float[N], ry = new float[N], rs = new float[N], rp = new float[N], rl = new float[N];
    private final float[] lines = new float[N * 4];

    // pre-formatted strings (no allocation while drawing)
    private String tempStr = "", cityStr = "", condStr = "", hlStr = "", updStr = "";
    private final String[] vals = new String[6];

    public WeatherWidgetView(Context c) {
        super(c);
        setFocusable(true);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        border.setStyle(Paint.Style.STROKE);
        Random r = new Random(11);
        for (int i = 0; i < N; i++) {
            rx[i] = r.nextFloat(); ry[i] = r.nextFloat(); rs[i] = r.nextFloat();
            rp[i] = r.nextFloat(); rl[i] = r.nextFloat();
        }
        setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), 2.2f * u);
            }
        });
        setClipToOutline(false);
        for (int i = 0; i < vals.length; i++) vals[i] = "--";
    }

    // ---------- public API ----------
    public void setListener(Listener l) { listener = l; }
    public void setBackdrop(WallpaperView w) { backdrop = w; }
    public void setLoading(boolean l) { loading = l; invalidate(); }
    public void setError(String e) { error = e; invalidate(); }

    public void setData(WeatherData d) {
        data = d;
        if (d != null) {
            tempStr = deg(d.temp);
            cityStr = d.city;
            condStr = WeatherCodes.label(d.code, d.isDay);
            hlStr = "H " + deg(d.high) + "   L " + deg(d.low);
            vals[0] = deg(d.feels);
            vals[1] = d.humidity + "%";
            vals[2] = Math.round(d.wind) + " km/h";
            vals[3] = Math.round(d.uv) + " \u00b7 " + uvLabel(d.uv);
            vals[4] = fmtClock(d.sunrise);
            vals[5] = fmtClock(d.sunset);
            updStr = DateFormat.getTimeFormat(getContext()).format(new Date(d.updatedMs));
        }
        rebuildShaders();
        invalidate();
    }

    // ---------- helpers ----------
    private static String deg(double v) { return Math.round(v) + "\u00b0"; }

    private static String uvLabel(double v) {
        if (v < 3) return "Low";
        if (v < 6) return "Mod";
        if (v < 8) return "High";
        if (v < 11) return "V.High";
        return "Extreme";
    }

    private String fmtClock(String hhmm) {
        try {
            if (DateFormat.is24HourFormat(getContext())) return hhmm;
            String[] p = hhmm.split(":");
            int hh = Integer.parseInt(p[0]), mm = Integer.parseInt(p[1]);
            String ap = hh >= 12 ? "PM" : "AM";
            hh %= 12;
            if (hh == 0) hh = 12;
            return hh + ":" + (mm < 10 ? "0" : "") + mm + " " + ap;
        } catch (Exception e) {
            return hhmm;
        }
    }

    private WeatherCodes.Kind kind() {
        return data == null ? WeatherCodes.Kind.CLOUDY : WeatherCodes.kind(data.code);
    }

    private boolean day() { return data != null && data.isDay; }

    private static int[] skyColors(WeatherCodes.Kind k, boolean day) {
        switch (k) {
            case SUNNY:  return day ? new int[]{0xB3FFC45A, 0x80FF8F3D} : new int[]{0xB30A1030, 0xB31B2559};
            case PARTLY: return day ? new int[]{0xA6E9B253, 0x8C4A86C8} : new int[]{0xB30B1233, 0xB3222B5E};
            case FOG:    return day ? new int[]{0x99A0AAB5, 0x99677079} : new int[]{0xB3333A46, 0xB31B1F27};
            case RAIN:   return day ? new int[]{0xB33B4B66, 0xB3202838} : new int[]{0xBD1A2233, 0xBD0C1019};
            case STORM:  return new int[]{0xD01F1C36, 0xD00A0A15};
            case SNOW:   return day ? new int[]{0xA6AFC1DA, 0xA6728CAA} : new int[]{0xB32E3C58, 0xB31B2539};
            default:     return day ? new int[]{0x99768397, 0x99454F5E} : new int[]{0xB32B3242, 0xB3151A24};
        }
    }

    private void rebuildShaders() {
        int w = getWidth(), h = getHeight();
        if (w == 0) return;
        int[] sc = skyColors(kind(), day());
        sky = new LinearGradient(0, 0, 0, h, sc[0], sc[1], Shader.TileMode.CLAMP);
        gloss = new LinearGradient(0, 0, 0, h * 0.55f, 0x30FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
        borderShader = new LinearGradient(0, 0, w, h, 0xB3FFFFFF, 0x26FFFFFF, Shader.TileMode.CLAMP);
        sunGlow = new RadialGradient(4.8f * u, 4.4f * u, 14f * u, 0x80FFD36B, 0x00FFD36B, Shader.TileMode.CLAMP);
        moonGlow = new RadialGradient(21.5f * u, 5.2f * u, 7f * u, 0x44FFF3C4, 0x00FFF3C4, Shader.TileMode.CLAMP);
        WeatherCodes.Kind k = kind();
        int cc = day() ? ((k == WeatherCodes.Kind.RAIN || k == WeatherCodes.Kind.STORM) ? 0x80B8C2D0 : 0xA8FFFFFF) : 0x55B8C2DC;
        cloudPaint.setShader(new RadialGradient(0, 0, 1f, cc, cc & 0x00FFFFFF, Shader.TileMode.CLAMP));
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        u = w / 26f;
        setElevation(1.6f * u);
        rf.set(0, 0, w, h);
        clip.reset();
        clip.addRoundRect(rf, 2.2f * u, 2.2f * u, Path.Direction.CW);
        rebuildShaders();
        invalidateOutline();
    }

    // ---------- focus & keys ----------
    @Override protected void onFocusChanged(boolean gained, int dir, Rect prev) {
        super.onFocusChanged(gained, dir, prev);
        animate().scaleX(gained ? 1.05f : 1f).scaleY(gained ? 1.05f : 1f).setDuration(180).start();
        ValueAnimator va = ValueAnimator.ofFloat(focus, gained ? 1f : 0f);
        va.setDuration(180);
        va.addUpdateListener(a -> { focus = (Float) a.getAnimatedValue(); invalidate(); });
        va.start();
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent e) {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER
                || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) {
            if (listener != null) listener.onRefreshRequested();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            if (listener != null) listener.onCityRequested();
            return true;
        }
        return super.onKeyUp(keyCode, e);
    }

    @Override protected void onWindowVisibilityChanged(int v) {
        super.onWindowVisibilityChanged(v);
        if (v == VISIBLE) invalidate();
    }

    // ---------- drawing ----------
    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        if (w == 0 || sky == null) return;
        float t = (SystemClock.uptimeMillis() - t0) / 1000f;
        WeatherCodes.Kind k = kind();
        boolean day = day();

        c.save();
        c.clipPath(clip);
        drawBackdrop(c, w, h);
        fill.setShader(null);
        fill.setColor(0x59000000);              // dark glass
        c.drawRect(0, 0, w, h, fill);
        fill.setShader(sky);                    // weather colour wash
        c.drawRect(0, 0, w, h, fill);
        fill.setShader(null);
        drawEffects(c, t, w, h, k, day);
        fill.setShader(gloss);                  // top highlight
        c.drawRect(0, 0, w, h * 0.55f, fill);
        fill.setShader(null);
        drawContent(c, t, w, h, k, day);
        c.restore();

        // border
        float bw = u * 0.1f;
        border.setShader(borderShader);
        border.setStrokeWidth(bw);
        rf.set(bw / 2, bw / 2, w - bw / 2, h - bw / 2);
        c.drawRoundRect(rf, 2.2f * u, 2.2f * u, border);
        if (focus > 0f) {
            border.setShader(null);
            border.setColor(((int) (focus * 235) << 24) | 0xFFFFFF);
            border.setStrokeWidth(u * 0.22f);
            rf.set(u * 0.11f, u * 0.11f, w - u * 0.11f, h - u * 0.11f);
            c.drawRoundRect(rf, 2.2f * u, 2.2f * u, border);
        }

        if (getVisibility() == VISIBLE) postInvalidateDelayed(FRAME_MS);
    }

    private void drawBackdrop(Canvas c, float w, float h) {
        if (backdrop == null || backdrop.getWidth() == 0) return;
        Bitmap b = backdrop.getBlur();
        if (b == null) return;
        float s = b.getWidth() / (float) backdrop.getWidth();
        int l = Math.max(0, (int) (getLeft() * s)), tp = Math.max(0, (int) (getTop() * s));
        int r = Math.min(b.getWidth(), (int) ((getLeft() + w) * s)), bt = Math.min(b.getHeight(), (int) ((getTop() + h) * s));
        if (r <= l || bt <= tp) return;
        src.set(l, tp, r, bt);
        dst.set(0, 0, (int) w, (int) h);
        c.drawBitmap(b, src, dst, bmpPaint);
    }

    private void drawEffects(Canvas c, float t, float w, float h, WeatherCodes.Kind k, boolean day) {
        if (data == null) { drawClouds(c, t, w, h, 2, 0.8f); return; }
        switch (k) {
            case SUNNY:
                if (day) drawSun(c, t); else drawNight(c, t, w, h);
                break;
            case PARTLY:
                if (day) drawSun(c, t); else drawNight(c, t, w, h);
                drawClouds(c, t, w, h, 2, 1f);
                break;
            case CLOUDY: drawClouds(c, t, w, h, 4, 1f); break;
            case FOG: drawClouds(c, t, w, h, 5, 1.3f); break;
            case RAIN: drawClouds(c, t, w, h, 3, 1f); drawRain(c, t, w, h, 28); break;
            case STORM: drawClouds(c, t, w, h, 4, 1f); drawRain(c, t, w, h, 40); drawLightning(c, t, w, h); break;
            case SNOW: drawClouds(c, t, w, h, 2, 0.8f); drawSnow(c, t, w, h); break;
        }
    }

    private void drawSun(Canvas c, float t) {
        float cx = 4.8f * u, cy = 4.4f * u;
        fill.setShader(sunGlow);
        fill.setAlpha((int) (255 * (0.85f + 0.15f * (float) Math.sin(t * 0.9f))));
        c.drawCircle(cx, cy, 14f * u, fill);
        fill.setShader(null);
        fill.setAlpha(255);
        line.setColor(0x2EFFE9A8);
        line.setStrokeWidth(0.55f * u);
        for (int i = 0; i < 6; i++) {
            c.save();
            c.rotate(t * 4f + i * 60f, cx, cy);
            c.drawLine(cx, cy, cx + 17f * u, cy, line);
            c.restore();
        }
    }

    private void drawNight(Canvas c, float t, float w, float h) {
        fill.setShader(null);
        for (int i = 0; i < 26; i++) {
            float a = 0.35f + 0.65f * (0.5f + 0.5f * (float) Math.sin(t * (0.8f + rs[i] * 1.6f) + rp[i] * 6.28f));
            fill.setColor(((int) (a * 255) << 24) | 0xFFFFFF);
            c.drawCircle(rx[i] * w, ry[i] * h * 0.9f, (0.07f + rl[i] * 0.09f) * u, fill);
        }
        float mx = 21.5f * u, my = 5.2f * u, mr = 2.4f * u;
        fill.setShader(moonGlow);
        c.drawCircle(mx, my, 7f * u, fill);
        fill.setShader(null);
        tmp.reset(); tmp.addCircle(mx, my, mr, Path.Direction.CW);
        tmp2.reset(); tmp2.addCircle(mx + mr * 0.55f, my - mr * 0.25f, mr * 0.92f, Path.Direction.CW);
        tmp.op(tmp2, Path.Op.DIFFERENCE);
        fill.setColor(0x99FFF6D8);
        c.drawPath(tmp, fill);
    }

    private void drawClouds(Canvas c, float t, float w, float h, int n, float scale) {
        for (int i = 0; i < n; i++) {
            float rxp = (4.5f + 3.5f * rs[i]) * u * scale, ryp = rxp * 0.4f;
            float span = w + 2 * rxp;
            float x = ((rx[i] * span + t * (0.5f + 0.8f * rl[i]) * u) % span) - rxp;
            float y = (0.12f + 0.6f * ry[i]) * h;
            c.save();
            c.translate(x, y);
            c.scale(rxp, ryp);
            c.drawCircle(0, 0, 1f, cloudPaint);
            c.restore();
        }
    }

    private void drawRain(Canvas c, float t, float w, float h, int n) {
        for (int i = 0; i < n; i++) {
            float speed = (14f + rs[i] * 10f) * u, len = (1.1f + rl[i]) * u;
            float y = ((t * speed + rp[i] * (h + len)) % (h + len)) - len;
            float x = rx[i] * w + y * 0.2f - 0.1f * h;
            lines[i * 4] = x; lines[i * 4 + 1] = y; lines[i * 4 + 2] = x + len * 0.2f; lines[i * 4 + 3] = y + len;
        }
        line.setColor(0x99CFE3FF);
        line.setStrokeWidth(0.09f * u);
        c.drawLines(lines, 0, n * 4, line);
    }

    private void drawSnow(Canvas c, float t, float w, float h) {
        fill.setColor(0xD0FFFFFF);
        for (int i = 0; i < 28; i++) {
            float r = (0.09f + rl[i] * 0.12f) * u, speed = (1.8f + rs[i] * 2.2f) * u;
            float y = ((t * speed + rp[i] * h) % (h + 4 * r)) - 2 * r;
            float x = rx[i] * w + (float) Math.sin(t * (0.8f + rs[i]) + rp[i] * 6.28f) * 1.1f * u;
            c.drawCircle(x, y, r, fill);
        }
    }

    private void drawLightning(Canvas c, float t, float w, float h) {
        float period = 5.5f, ph = t % period;
        int cycle = (int) (t / period);
        float amt = 0f;
        if (ph < 0.12f) amt = 1f - ph / 0.12f;
        else if (ph > 0.3f && ph < 0.5f) amt = 0.8f * (1f - (ph - 0.3f) / 0.2f);
        if (amt <= 0f) return;
        fill.setShader(null);
        fill.setColor(((int) (amt * 0x55) << 24) | 0xFFFFFF);
        c.drawRect(0, 0, w, h, fill);
        Random br = new Random(cycle * 7919L + 3);
        float x = (0.3f + 0.4f * br.nextFloat()) * w, y = 0;
        tmp.reset(); tmp.moveTo(x, y);
        for (int i = 0; i < 6; i++) { y += h / 6f; x += (br.nextFloat() - 0.5f) * 3.2f * u; tmp.lineTo(x, y); }
        line.setColor(((int) (amt * 90) << 24) | 0xBFD9FF);
        line.setStrokeWidth(0.9f * u);
        c.drawPath(tmp, line);
        line.setColor(((int) (amt * 255) << 24) | 0xFFFFFF);
        line.setStrokeWidth(0.22f * u);
        c.drawPath(tmp, line);
    }

    // ---------- text content ----------
    private void txt(float size, int color, Typeface tf, Paint.Align al) {
        text.setTextSize(size); text.setColor(color); text.setTypeface(tf); text.setTextAlign(al);
        text.setShadowLayer(u * 0.3f, 0, u * 0.12f, 0x73000000);
    }

    private String fit(String s, float maxW) {
        return TextUtils.ellipsize(s, text, maxW, TextUtils.TruncateAt.END).toString();
    }

    private void drawContent(Canvas c, float t, float w, float h, WeatherCodes.Kind k, boolean day) {
        if (data == null) {
            txt(2f * u, 0xFFFFFFFF, MEDIUM, Paint.Align.CENTER);
            c.drawText("Weather", w / 2, h * 0.42f, text);
            txt(1.25f * u, 0xB3FFFFFF, REGULAR, Paint.Align.CENTER);
            String m = loading ? "Updating\u2026" : (error != null ? error : "Press OK to load");
            c.drawText(fit(m, w - 3 * u), w / 2, h * 0.42f + 2.4f * u, text);
            return;
        }
        drawIcon(c, 4.9f * u, 4.5f * u, 6.2f * u, k, day, t);
        txt(4.8f * u, 0xFFFFFFFF, LIGHT, Paint.Align.LEFT);
        c.drawText(tempStr, 8.7f * u, 6.6f * u, text);

        float right = 24.4f * u, maxW = 7.6f * u;
        txt(1.55f * u, 0xFFFFFFFF, MEDIUM, Paint.Align.RIGHT);
        c.drawText(fit(cityStr, maxW), right, 2.9f * u, text);
        txt(1.25f * u, 0xD9FFFFFF, REGULAR, Paint.Align.RIGHT);
        c.drawText(fit(condStr, maxW), right, 4.6f * u, text);
        c.drawText(hlStr, right, 6.3f * u, text);

        line.setColor(0x33FFFFFF);
        line.setStrokeWidth(0.07f * u);
        c.drawLine(1.6f * u, 8.0f * u, 24.4f * u, 8.0f * u, line);

        for (int i = 0; i < 6; i++) {
            float x = 1.6f * u + (i % 3) * 7.8f * u;
            float yl = (i < 3 ? 9.9f : 12.9f) * u;
            txt(1.0f * u, 0x99FFFFFF, REGULAR, Paint.Align.LEFT);
            text.setLetterSpacing(0.06f);
            c.drawText(LABELS[i], x, yl, text);
            text.setLetterSpacing(0f);
            txt(1.4f * u, 0xFFFFFFFF, MEDIUM, Paint.Align.LEFT);
            c.drawText(vals[i], x, yl + 1.65f * u, text);
        }

        txt(0.95f * u, 0x99FFFFFF, REGULAR, Paint.Align.LEFT);
        String bottom;
        if (focus > 0.5f) bottom = "OK  Refresh     MENU  Change city";
        else if (loading) bottom = "Updating\u2026";
        else if (error != null) bottom = error + " \u00b7 " + updStr;
        else bottom = "Updated " + updStr;
        c.drawText(fit(bottom, w - 3.2f * u), 1.6f * u, 16.35f * u, text);
    }

    // ---------- weather icons ----------
    private void drawIcon(Canvas c, float cx, float cy, float s, WeatherCodes.Kind k, boolean day, float t) {
        fill.setShader(null);
        switch (k) {
            case SUNNY:
                if (day) sun(c, cx, cy, s * 0.9f, t); else moon(c, cx, cy, s * 0.9f);
                break;
            case PARTLY:
                if (day) sun(c, cx - 0.16f * s, cy - 0.16f * s, s * 0.7f, t); else moon(c, cx - 0.16f * s, cy - 0.16f * s, s * 0.7f);
                cloud(c, cx + 0.04f * s, cy + 0.1f * s, s * 0.9f, 0xFFF4F7FB);
                break;
            case CLOUDY:
                cloud(c, cx + 0.12f * s, cy - 0.1f * s, s * 0.8f, 0xFFB7C1CF);
                cloud(c, cx - 0.04f * s, cy + 0.08f * s, s, 0xFFE9EDF3);
                break;
            case FOG:
                cloud(c, cx, cy - 0.12f * s, s * 0.85f, 0xFFD5DBE4);
                line.setColor(0xCCFFFFFF);
                line.setStrokeWidth(0.045f * s);
                for (int j = 0; j < 3; j++) {
                    float dx = (float) Math.sin(t * 0.8f + j) * 0.04f * s;
                    float y = cy + (0.26f + j * 0.1f) * s;
                    c.drawLine(cx - 0.3f * s + dx + j * 0.05f * s, y, cx + 0.3f * s + dx - j * 0.05f * s, y, line);
                }
                break;
            case RAIN:
                cloud(c, cx, cy - 0.1f * s, s, 0xFFC4CEDB);
                line.setStrokeWidth(0.045f * s);
                for (int j = 0; j < 3; j++) {
                    float ph = (t * 1.6f + j * 0.33f) % 1f;
                    float x = cx - 0.18f * s + j * 0.18f * s, y = cy + (0.2f + ph * 0.22f) * s;
                    line.setColor(((int) ((1f - ph) * 255) << 24) | 0x6FB6FF);
                    c.drawLine(x, y, x - 0.04f * s, y + 0.1f * s, line);
                }
                break;
            case STORM:
                cloud(c, cx, cy - 0.12f * s, s, 0xFF8E98AB);
                tmp.reset();
                tmp.moveTo(cx + 0.02f * s, cy + 0.15f * s);
                tmp.lineTo(cx - 0.08f * s, cy + 0.35f * s);
                tmp.lineTo(cx, cy + 0.35f * s);
                tmp.lineTo(cx - 0.06f * s, cy + 0.5f * s);
                tmp.lineTo(cx + 0.12f * s, cy + 0.28f * s);
                tmp.lineTo(cx + 0.03f * s, cy + 0.28f * s);
                tmp.lineTo(cx + 0.1f * s, cy + 0.15f * s);
                tmp.close();
                fill.setColor(0xFFFFD84A);
                c.drawPath(tmp, fill);
                break;
            case SNOW:
                cloud(c, cx, cy - 0.1f * s, s, 0xFFDCE6F2);
                for (int j = 0; j < 3; j++) {
                    float ph = (t * 0.7f + j * 0.33f) % 1f;
                    fill.setColor(((int) ((1f - ph) * 255) << 24) | 0xFFFFFF);
                    c.drawCircle(cx - 0.18f * s + j * 0.18f * s + (float) Math.sin(t + j) * 0.03f * s,
                            cy + (0.22f + ph * 0.22f) * s, 0.035f * s, fill);
                }
                break;
        }
    }

    private void sun(Canvas c, float cx, float cy, float size, float t) {
        float r = size * 0.24f;
        line.setColor(0xFFFFD34E);
        line.setStrokeWidth(size * 0.07f);
        for (int i = 0; i < 8; i++) {
            c.save();
            c.rotate(t * 18f + i * 45f, cx, cy);
            c.drawLine(cx + r * 1.45f, cy, cx + r * 1.95f, cy, line);
            c.restore();
        }
        fill.setColor(0xFFFFC83D);
        c.drawCircle(cx, cy, r, fill);
        fill.setColor(0xFFFFE08A);
        c.drawCircle(cx - r * 0.15f, cy - r * 0.15f, r * 0.62f, fill);
    }

    private void moon(Canvas c, float cx, float cy, float size) {
        float r = size * 0.3f;
        tmp.reset(); tmp.addCircle(cx, cy, r, Path.Direction.CW);
        tmp2.reset(); tmp2.addCircle(cx + r * 0.55f, cy - r * 0.3f, r * 0.9f, Path.Direction.CW);
        tmp.op(tmp2, Path.Op.DIFFERENCE);
        fill.setColor(0xFFFFF1C2);
        c.drawPath(tmp, fill);
        fill.setColor(0xCCFFFFFF);
        c.drawCircle(cx + r * 0.9f, cy - r * 0.9f, size * 0.025f, fill);
        c.drawCircle(cx + r * 1.2f, cy + r * 0.2f, size * 0.018f, fill);
    }

    private void cloud(Canvas c, float cx, float cy, float s, int color) {
        fill.setColor(color);
        c.drawCircle(cx - 0.17f * s, cy + 0.02f * s, 0.17f * s, fill);
        c.drawCircle(cx + 0.02f * s, cy - 0.10f * s, 0.23f * s, fill);
        c.drawCircle(cx + 0.20f * s, cy + 0.03f * s, 0.16f * s, fill);
        rf.set(cx - 0.34f * s, cy + 0.02f * s, cx + 0.36f * s, cy + 0.19f * s);
        c.drawRoundRect(rf, 0.085f * s, 0.085f * s, fill);
    }
}
