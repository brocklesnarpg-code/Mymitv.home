package com.example.glassylauncher;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** tvOS-style "Control Center": quick actions, network, brightness and volume. */
final class ControlCenter extends FrameLayout {

    interface Host {
        String networkLabel();
        void sleepScreen();
        void nextWallpaper();
        void refreshWeather();
        void openSettingsDrawer();
        void openApps();
        void openInputs();
        int brightness();
        void setBrightness(int v);
        int volume();
        void setVolume(int v);
        int accent();
        void controlCenterClosed();
    }

    private final Host host;
    private final float u;
    private boolean open;
    private LinearLayout first;
    private TextView netSub;
    private GlassSlider bright, vol;

    ControlCenter(Context ctx, Host host, float u) {
        super(ctx);
        this.host = host;
        this.u = u;
        setVisibility(GONE);
        setClickable(true);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEB161A22);
        bg.setCornerRadius(2.4f * u);
        bg.setStroke((int) Math.max(1, 0.1f * u), 0x40FFFFFF);
        setBackground(bg);
        setElevation(6 * u);

        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (1.4f * u);
        col.setPadding(pad, pad, pad, pad);
        addView(col, new LayoutParams(-1, -2));

        TextView title = text("Control Center", 1.8f, 0xFFFFFFFF, Typeface.DEFAULT_BOLD);
        title.setPadding((int) (0.6f * u), 0, 0, (int) (0.8f * u));
        col.addView(title);

        first = item("Sleep screen", "Turn the screen black", host::sleepScreen);
        col.addView(first, lp(0));
        LinearLayout net = item("Network", "", null);
        netSub = (TextView) net.getChildAt(1);
        col.addView(net, lp(0.5f));

        LinearLayout g1 = new LinearLayout(ctx);
        g1.addView(item("Apps", "", host::openApps), half());
        g1.addView(item("Wallpaper", "", host::nextWallpaper), half());
        col.addView(g1, lp(0.5f));
        LinearLayout g2 = new LinearLayout(ctx);
        g2.addView(item("Refresh", "weather", host::refreshWeather), half());
        g2.addView(item("Settings", "", host::openSettingsDrawer), half());
        col.addView(g2, lp(0.5f));

        bright = new GlassSlider(ctx, "Brightness", u, host.brightness(), host.accent(), host::setBrightness);
        col.addView(bright, sliderLp());
        vol = new GlassSlider(ctx, "Volume", u, host.volume(), host.accent(), host::setVolume);
        col.addView(vol, sliderLp());
        col.addView(item("TV inputs", "HDMI and other sources", host::openInputs), lp(0.5f));
    }

    boolean isOpen() { return open; }

    void open() {
        if (open) return;
        open = true;
        netSub.setText(host.networkLabel());
        bright.setAccent(host.accent());
        vol.setAccent(host.accent());
        setVisibility(VISIBLE);
        setAlpha(0f);
        setTranslationY(-1.5f * u);
        animate().alpha(1f).translationY(0).setDuration(200).start();
        first.requestFocus();
    }

    void close() {
        if (!open) return;
        open = false;
        animate().alpha(0f).setDuration(150).withEndAction(() -> setVisibility(GONE)).start();
        host.controlCenterClosed();
    }

    private TextView text(String s, float sizeU, int color, Typeface tf) {
        TextView t = new TextView(getContext());
        t.setText(s);
        t.setTextColor(color);
        t.setTypeface(tf);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeU * u);
        return t;
    }

    private LinearLayout.LayoutParams lp(float topU) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-1, -2);
        l.topMargin = (int) (topU * u);
        return l;
    }

    private LinearLayout.LayoutParams half() {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, -2, 1f);
        l.rightMargin = (int) (0.25f * u);
        l.leftMargin = (int) (0.25f * u);
        return l;
    }

    private LinearLayout.LayoutParams sliderLp() {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-1, (int) (3.6f * u));
        l.topMargin = (int) (0.6f * u);
        return l;
    }

    private LinearLayout item(String title, String sub, final Runnable ok) {
        final LinearLayout r = new LinearLayout(getContext());
        r.setOrientation(LinearLayout.VERTICAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setFocusable(true);
        r.setClickable(true);
        r.setPadding((int) (1.4f * u), (int) (0.9f * u), (int) (1.4f * u), (int) (0.9f * u));
        final GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(1.8f * u);
        bg.setColor(0x30FFFFFF);
        r.setBackground(bg);
        r.addView(text(title, 1.45f, 0xFFFFFFFF, Typeface.create("sans-serif-medium", Typeface.NORMAL)));
        TextView s = text(sub, 1.05f, 0xA6FFFFFF, Typeface.DEFAULT);
        r.addView(s);
        r.setOnFocusChangeListener((x, f) -> {
            bg.setColor(f ? 0x66FFFFFF : 0x30FFFFFF);
            bg.setStroke(f ? (int) (0.18f * u) : 0, 0xF2FFFFFF);
            x.animate().scaleX(f ? 1.03f : 1f).scaleY(f ? 1.03f : 1f).setDuration(140).start();
        });
        r.setOnClickListener(x -> {
            if (ok != null) ok.run();
            netSub.setText(host.networkLabel());
        });
        r.setOnKeyListener((x, code, e) ->
                e.getAction() == KeyEvent.ACTION_DOWN
                        && (code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT)
                        && (x.getParent() == null || !(x.getParent() instanceof LinearLayout)
                        || ((LinearLayout) x.getParent()).getOrientation() == LinearLayout.VERTICAL));
        return r;
    }
}
