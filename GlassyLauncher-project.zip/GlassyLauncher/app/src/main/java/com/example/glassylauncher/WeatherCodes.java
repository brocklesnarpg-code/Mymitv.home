package com.example.glassylauncher;

/** Maps Open-Meteo WMO weather codes to a visual kind and a label. */
public final class WeatherCodes {
    private WeatherCodes() {}

    public enum Kind { SUNNY, PARTLY, CLOUDY, FOG, RAIN, STORM, SNOW }

    public static Kind kind(int c) {
        if (c <= 1) return Kind.SUNNY;
        if (c == 2) return Kind.PARTLY;
        if (c == 3) return Kind.CLOUDY;
        if (c == 45 || c == 48) return Kind.FOG;
        if (c >= 95) return Kind.STORM;
        if ((c >= 71 && c <= 77) || c == 85 || c == 86) return Kind.SNOW;
        if (c >= 51) return Kind.RAIN;
        return Kind.CLOUDY;
    }

    public static String label(int c, boolean day) {
        switch (c) {
            case 0: return day ? "Sunny" : "Clear";
            case 1: return day ? "Mostly sunny" : "Mostly clear";
            case 2: return "Partly cloudy";
            case 3: return "Overcast";
            case 45: case 48: return "Foggy";
            case 51: case 53: case 55: case 56: case 57: return "Drizzle";
            case 61: return "Light rain";
            case 63: return "Rain";
            case 65: return "Heavy rain";
            case 66: case 67: return "Freezing rain";
            case 71: case 73: case 75: case 77: return "Snow";
            case 80: case 81: case 82: return "Rain showers";
            case 85: case 86: return "Snow showers";
            case 95: return "Thunderstorm";
            case 96: case 99: return "Thunderstorm, hail";
            default: return "Cloudy";
        }
    }
}
