package com.example.glassylauncher;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Location + Open-Meteo access with an offline cache. All network work runs on a
 * single background thread; callbacks are delivered on the main thread.
 */
public final class WeatherRepository {

    public static final class Place {
        public final String name, subtitle;
        public final double lat, lon;
        public Place(String name, String subtitle, double lat, double lon) {
            this.name = name; this.subtitle = subtitle; this.lat = lat; this.lon = lon;
        }
    }

    public interface Callback { void onResult(WeatherData data, String error); }
    public interface SearchCallback { void onResult(List<Place> places, String error); }

    private static final String K_AUTO = "auto", K_NAME = "name", K_LAT = "lat", K_LON = "lon", K_CACHE = "cache";

    private final Context ctx;
    private final SharedPreferences sp;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    public WeatherRepository(Context c) {
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences("weather", Context.MODE_PRIVATE);
    }

    // ---------- settings ----------
    public boolean isAuto() { return sp.getBoolean(K_AUTO, true); }

    public void setAuto() { sp.edit().putBoolean(K_AUTO, true).apply(); }

    public void setManualCity(Place p) {
        sp.edit().putBoolean(K_AUTO, false).putString(K_NAME, p.name)
                .putString(K_LAT, Double.toString(p.lat)).putString(K_LON, Double.toString(p.lon)).apply();
    }

    public String locationLabel() {
        return isAuto() ? "Automatic" : sp.getString(K_NAME, "Custom");
    }

    public boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < 23) return true;
        return ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    // ---------- cache ----------
    public WeatherData loadCached() {
        String s = sp.getString(K_CACHE, null);
        return s == null ? null : WeatherData.fromJson(s);
    }

    private void save(WeatherData w) {
        try { sp.edit().putString(K_CACHE, w.toJson()).apply(); } catch (Exception ignored) {}
    }

    // ---------- public API ----------
    public void refresh(final Callback cb) {
        io.execute(() -> {
            WeatherData result;
            String err = null;
            try {
                result = fetch(resolvePlace());
                save(result);
            } catch (Exception e) {
                boolean net = e instanceof IOException;
                result = loadCached();
                err = result != null
                        ? (net ? "Offline \u00b7 saved weather" : "Weather unavailable \u00b7 saved data")
                        : (net ? "No internet connection" : "Weather unavailable");
            }
            final WeatherData fr = result;
            final String fe = err;
            main.post(() -> cb.onResult(fr, fe));
        });
    }

    public void searchCities(final String q, final SearchCallback cb) {
        io.execute(() -> {
            List<Place> out = new ArrayList<>();
            String err = null;
            try {
                String body = get("https://geocoding-api.open-meteo.com/v1/search?name="
                        + URLEncoder.encode(q, "UTF-8") + "&count=8&language=en&format=json");
                JSONArray r = new JSONObject(body).optJSONArray("results");
                if (r != null) {
                    for (int i = 0; i < r.length(); i++) {
                        JSONObject o = r.getJSONObject(i);
                        StringBuilder sub = new StringBuilder();
                        if (!o.isNull("admin1")) sub.append(o.getString("admin1"));
                        if (!o.isNull("country")) {
                            if (sub.length() > 0) sub.append(", ");
                            sub.append(o.getString("country"));
                        }
                        out.add(new Place(o.getString("name"), sub.toString(),
                                o.getDouble("latitude"), o.getDouble("longitude")));
                    }
                }
            } catch (Exception e) {
                err = "Search failed \u2013 check your connection";
            }
            final String fe = err;
            main.post(() -> cb.onResult(out, fe));
        });
    }

    // ---------- internals ----------
    private Place resolvePlace() throws IOException {
        if (!isAuto()) {
            return new Place(sp.getString(K_NAME, null), "",
                    Double.parseDouble(sp.getString(K_LAT, "0")), Double.parseDouble(sp.getString(K_LON, "0")));
        }
        double[] ll = lastKnown();
        if (ll != null) return new Place(reverse(ll[0], ll[1]), "", ll[0], ll[1]);
        return ipLookup(); // permission denied / no GPS (most TVs): approximate location by IP
    }

    private double[] lastKnown() {
        if (!hasLocationPermission()) return null;
        try {
            LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) return null;
            Location best = null;
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            return best == null ? null : new double[]{best.getLatitude(), best.getLongitude()};
        } catch (SecurityException | IllegalArgumentException e) {
            return null;
        }
    }

    private String reverse(double lat, double lon) {
        try {
            if (!Geocoder.isPresent()) return null;
            List<Address> a = new Geocoder(ctx, Locale.getDefault()).getFromLocation(lat, lon, 1);
            if (a == null || a.isEmpty()) return null;
            Address ad = a.get(0);
            if (ad.getLocality() != null) return ad.getLocality();
            if (ad.getSubAdminArea() != null) return ad.getSubAdminArea();
            return ad.getAdminArea();
        } catch (Exception e) {
            return null;
        }
    }

    private Place ipLookup() throws IOException {
        try {
            JSONObject j = new JSONObject(get("https://ipwho.is/"));
            if (j.optBoolean("success", true) && j.has("latitude")) {
                return new Place(j.isNull("city") ? null : j.getString("city"), "",
                        j.getDouble("latitude"), j.getDouble("longitude"));
            }
        } catch (Exception ignored) {}
        try {
            JSONObject j = new JSONObject(get("https://ipapi.co/json/"));
            return new Place(j.isNull("city") ? null : j.getString("city"), "",
                    j.getDouble("latitude"), j.getDouble("longitude"));
        } catch (Exception e) {
            throw new IOException("Location lookup failed");
        }
    }

    private WeatherData fetch(Place p) throws Exception {
        String url = String.format(Locale.US,
                "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
                        + "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,is_day,uv_index"
                        + "&daily=temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max"
                        + "&timezone=auto&forecast_days=1&wind_speed_unit=kmh", p.lat, p.lon);
        JSONObject j = new JSONObject(get(url));
        JSONObject cur = j.getJSONObject("current");
        JSONObject d = j.getJSONObject("daily");

        WeatherData w = new WeatherData();
        w.lat = p.lat; w.lon = p.lon;
        w.temp = cur.getDouble("temperature_2m");
        w.feels = cur.getDouble("apparent_temperature");
        w.humidity = cur.getInt("relative_humidity_2m");
        w.code = cur.getInt("weather_code");
        w.wind = cur.getDouble("wind_speed_10m");
        w.isDay = cur.getInt("is_day") == 1;
        w.uv = cur.isNull("uv_index") ? d.getJSONArray("uv_index_max").optDouble(0, 0) : cur.getDouble("uv_index");
        w.high = d.getJSONArray("temperature_2m_max").getDouble(0);
        w.low = d.getJSONArray("temperature_2m_min").getDouble(0);
        w.sunrise = timePart(d.getJSONArray("sunrise").getString(0));
        w.sunset = timePart(d.getJSONArray("sunset").getString(0));
        w.updatedMs = System.currentTimeMillis();
        if (p.name != null && !p.name.isEmpty()) {
            w.city = p.name;
        } else {
            String tz = j.optString("timezone", "");
            int i = tz.lastIndexOf('/');
            w.city = tz.isEmpty() ? "Current location" : tz.substring(i + 1).replace('_', ' ');
        }
        return w;
    }

    private static String timePart(String iso) {
        int i = iso.indexOf('T');
        return i >= 0 ? iso.substring(i + 1) : iso;
    }

    private static String get(String url) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(10000);
        c.setRequestProperty("User-Agent", "GlassyLauncher/2.0");
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }
}
